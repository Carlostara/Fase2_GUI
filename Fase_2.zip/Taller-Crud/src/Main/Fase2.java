
package Main;
import Vista.Login;


public class Fase2 {

    
    public static void main(String[] args) {
        
        
      Login registro = new Login();
      registro.setVisible(true);
      registro.setLocationRelativeTo(null);
      
    }
    
}
